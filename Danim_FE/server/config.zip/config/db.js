const mysql = require('mysql');

const db = mysql.createPool({
  host: 'localhost',
  user: 'danim',
  password: 'Danim1024!@',
  database: 'danim',
});

module.exports = db;
